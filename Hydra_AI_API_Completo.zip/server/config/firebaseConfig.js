// Configuração Firebase
module.exports = {...};