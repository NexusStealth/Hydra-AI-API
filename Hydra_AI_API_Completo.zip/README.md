# Hydra AI + API
Documentação básica do projeto.