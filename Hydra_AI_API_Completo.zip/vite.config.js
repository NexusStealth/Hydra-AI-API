// Configurações Vite
export default {...};